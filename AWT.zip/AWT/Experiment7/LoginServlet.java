package remoWeb;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletRequest request;

    public LoginServlet() {
        // TODO Auto-generated constructor stub
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		        String fname = request.getParameter("fname");
		        String lname = request.getParameter("lname");
		        String email = request.getParameter("email");

		        System.out.println("First name: " + fname);
		        System.out.println("Last name: " + lname);
		        System.out.println("email: " + email);		
		        PrintWriter writer = response.getWriter();

		        String htmlRespone = "<html>";
		        htmlRespone += "<h2>Your First name is: " + fname + "<br/>";      
		        htmlRespone += "<h2>Your Last name is: " + lname + "<br/>";   
		        htmlRespone += "<h2>Your e-mail id is: " + email + "<br/>";   
		        htmlRespone += "</html>";
		        writer.println(htmlRespone);
		    }
	}
