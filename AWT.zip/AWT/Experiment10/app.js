const http = require('http')
const hostname = '127.0.01'
const port = 3000
http
    .get('http://api.open-notify.org/astros.json', resp => {
        let data = ''
        resp.on('data', chunk => {
            data += chunk
        })
        resp.on('end', () => {
            let peopleData = JSON.parse(data)
            console.log(peopleData)
        })
    })
    .on('error', err => {
        console.log("Error: ", err.message)
    })

    resp.on('end', () => {
        let peopleData = JSON.parse(data)
        
        const server = http.createServer((req, res) => {
            res.statusCode = 200
                
            res.setHeader('Content-Type', 'application/json')
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.end(JSON.stringify(stuff.people))
        })
        server.listen(port, hostname, () => {
                console.log(`Server running at http://${hostname}:${port}/`)
        })
    })
        