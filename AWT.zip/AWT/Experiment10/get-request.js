const getPosts = () => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts');
    xhr.responseType = 'json';
    xhr.onload = () => {
      console.log(xhr.response);
    }
    xhr.send();
};

getPosts();