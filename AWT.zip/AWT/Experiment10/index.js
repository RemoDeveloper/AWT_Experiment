window.addEventListener('DOMContentLoaded', (event) => {
    console.log('DOM fully loaded and parsed');
    let body = document.querySelector('body')
    let h3 = document.createElement('h3')
    h3.innerHTML = 'People in Space Right Now!'
    body.appendChild(h3)
    let button = document.createElement('button')
    button.innerText = 'Who is in space?'
    body.append(button)
    button.addEventListener('click', getPeople)

    function getPeople() {
        fetch('http://localhost:8080/')
        .then(resp => resp.json())
        .then(people =>{
            let ul = document.createElement('ul')
            body.append(ul)
            people.map(p =>{
                let li = document.createElement('li')
                li.innerHTML =  '<h4> ${p.name}</h4> <p>Assigned to : ${p.craft}</p>'
                ul.append(li)
            })

        })
    }
})