function valid(){
	let user = document.getElementById('user').value;
	let e_mail = document.getElementById('email').value;
	let pss = document.getElementById('passw').value;
	let tr = document.info.term;
	let gnder = document.info.rb;

	if (user == '') {
		document.getElementById('usr').innerHTML = '**Please enter name...';
		return false;
	}
	else if (user.length <= 2 || user.length >= 20){
		document.getElementById('usr').innerHTML = '**Name must have 2 to 20 characters...';
		return false;
	}
	else if (!isNaN(user)){
		document.getElementById('usr').innerHTML = '**Only characters...';
		return false;
	}

	if (e_mail == '') {
		document.getElementById('mail').innerHTML = '**Please enter mail id...';
		return false;
	}

	if (pss == '') {
		document.getElementById('pass').innerHTML = '**Please enter password...';
		return false;
	}
	else if (pss.length <= 2 || pss.length >= 20){
		document.getElementById('pass').innerHTML = '**Password must have 2 to 20 characters...';
		return false;
	}	

	if (!gnder[0].checked && !gnder[1].checked && !gnder[2].checked) {
		document.getElementById('gndr').innerHTML = '**Please select gender...';
		return false;
	}

	if (!tr.checked) {
		document.getElementById('trms').innerHTML = '**Please accept T&C...';
		return false;
	}
	
}

